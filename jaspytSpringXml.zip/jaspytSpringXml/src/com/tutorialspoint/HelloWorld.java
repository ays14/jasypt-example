package com.tutorialspoint;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;

public class HelloWorld {

	private String message;
	private String sample;
	private String algorithm;
	private String password;

	public void getMessage() {
		System.out.println("Your message: " + message);
//		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void getSample() {
		System.out.println("Your sample: " + sample);
//		return sample;
	}

	public void setSample(String sample) {
		this.sample = sample;
	}

	public String getAlgorithm() {
		return algorithm;
	}

	public void setAlgorithm(String algorithm) {
		this.algorithm = algorithm;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public StandardPBEStringEncryptor getStringEncryptor() {
		StandardPBEStringEncryptor encryptor = new StandardPBEStringEncryptor();
		encryptor.setPassword(System.getenv(password));
		encryptor.setAlgorithm(System.getenv(algorithm));
		return encryptor;
	}
}
