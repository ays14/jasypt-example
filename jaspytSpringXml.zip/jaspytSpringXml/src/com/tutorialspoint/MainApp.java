package com.tutorialspoint;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.jasypt.encryption.pbe.StandardPBEStringEncryptor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
	      HelloWorld obj = (HelloWorld) context.getBean("helloWorld");
	      obj.getMessage();
	      obj.getSample();
	      
	      StandardPBEStringEncryptor encryptor = obj.getStringEncryptor();
//	      StandardPBEStringEncryptor encryptor = (StandardPBEStringEncryptor) context.getBean("jasyptPBEStringEncryptor");
	      String nonEncrypted = args[0];
	      System.out.println(nonEncrypted);
	      
	      String encrypted = encryptor.encrypt(nonEncrypted);
	      
	      System.out.println(encrypted);
	      
      	String decrypted = encryptor.decrypt(encrypted);
	      
	      System.out.println(decrypted);
	      
//	      
//	      DataSource db = (DataSource) context.getBean("dataSource");
	      
//	      Connection connection = db.getConnection();
	}

}
